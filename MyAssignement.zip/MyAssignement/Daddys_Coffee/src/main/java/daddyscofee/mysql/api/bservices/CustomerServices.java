package daddyscofee.mysql.api.bservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import daddyscofee.mysql.api.dao.CustomersDao;
import daddyscofee.mysql.api.model.Customer;


@Service
public class CustomerServices {
	@Autowired
	private CustomersDao dao;
	
	

	public void addCustomer(Customer customers) {
		
		dao.save(customers);
	}



	public List<Customer> getAllCustomers() {
		
			List<Customer> customers = new ArrayList<>();
			dao.findAll()
			.forEach(customers::add);
			return customers;
		}



	public Optional<Customer> getCustomer(int id) {
		
		return dao.findById(id);
	}



	public void updateCustomer(int id, Customer customers) {
		
		dao.save(customers);
	}



	public void deleteCustomer(int id) {
		
		dao.deleteById(id);
		
	}
}
