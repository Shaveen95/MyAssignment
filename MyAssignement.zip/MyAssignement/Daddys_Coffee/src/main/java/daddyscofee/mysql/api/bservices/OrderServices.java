package daddyscofee.mysql.api.bservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import daddyscofee.mysql.api.dao.OrderItemsDao;
import daddyscofee.mysql.api.model.Orders;

@Service
public class OrderServices {
	
	@Autowired
	private OrderItemsDao dao;

	public void addOrder(Orders orders) {
		dao.save(orders);
		
	}

	public List<Orders> getAllOrders() {
		List<Orders> orders = new ArrayList<>();
		dao.findAll()
		.forEach(orders::add);
		return orders;
	}

	public Optional<Orders> getOrder(String id) {
		
		return dao.findById(id);
	}

	public void updateOrder(String id, Orders order) {
		dao.save(order);
		
	}

	public void deleteOrder(String id) {
		dao.deleteById(id);
		
	}
	
	

}
