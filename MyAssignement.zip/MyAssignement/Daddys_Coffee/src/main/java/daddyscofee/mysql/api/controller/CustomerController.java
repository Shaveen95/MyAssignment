package daddyscofee.mysql.api.controller;



import java.util.List;
import java.util.Optional;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import daddyscofee.mysql.api.bservices.CustomerServices;
//import daddyscofee.mysql.api.dao.CustomersDao;
import daddyscofee.mysql.api.model.Customer;



@RestController
public class CustomerController {
	@Autowired
	private CustomerServices customerService;
	
	@RequestMapping(method = RequestMethod.POST, value = "/addCustomer")
	public void addCustomer(@RequestBody Customer customers) {
		customerService.addCustomer(customers);
	}
	
	
	@RequestMapping("/showCustomers")
	public List<Customer> getAllCustomers(){
		return customerService.getAllCustomers() ;
	}
	
	@RequestMapping("/showCustomers/{id}")
	public Optional<Customer> getCustomer(@PathVariable int id) {
		return customerService.getCustomer(id);
		
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/updateCustomer/{id}")
	public void updateCustomer(@RequestBody Customer customers, @PathVariable int id) {
		customerService.updateCustomer(id, customers);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteCustomer/{id}")
	public void deleteCustomer(@PathVariable int id) {
		customerService.deleteCustomer(id);
		
	}

}
