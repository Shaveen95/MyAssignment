package daddyscofee.mysql.api.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import daddyscofee.mysql.api.bservices.OrderServices;
import daddyscofee.mysql.api.model.Orders;

@RestController
public class OrderController {

	@Autowired
	private OrderServices orderServices;
	
	@RequestMapping(method = RequestMethod.POST, value = "/addOrder")
	public void addOrder(@RequestBody Orders orders) {
		orderServices.addOrder(orders);
	}
	
	
	@RequestMapping("/showOrders")
	public List<Orders> getAllOrders(){
		return orderServices.getAllOrders() ;
	}
	
	@RequestMapping("/showOrders/{id}")
	public Optional<Orders> getItem(@PathVariable String id) {
		return orderServices.getOrder(id);
		
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/updateOrder/{id}")
	public void updateOrder(@RequestBody Orders order, @PathVariable String id) {
		orderServices.updateOrder(id,order);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteOrder/{id}")
	public void deleteOrder(@PathVariable String id){
		orderServices.deleteOrder(id);
		
	}
}
