package daddyscofee.mysql.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;




@SpringBootApplication
public class DaddysCoffeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaddysCoffeeApplication.class, args);
	}

}
