package daddyscofee.mysql.api.dao;

import org.springframework.data.repository.CrudRepository;

import daddyscofee.mysql.api.model.Items;

public interface ItemsDao extends CrudRepository<Items,String> {

}
