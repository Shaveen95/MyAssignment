package daddyscofee.mysql.api.model;

import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;





@Entity
@Table(name = "Customer")
public class Customer {
	
	@Id
	private int id;
	private String name;
	private String address;
	private int tp;
	
	public Customer() {
		
	}
	
	public Customer(int id, String name, String address, int tp) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.tp = tp;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getTpNo() {
		return tp;
	}
	public void setTpNo(int tp) {
		this.tp = tp;
	}
	
}
