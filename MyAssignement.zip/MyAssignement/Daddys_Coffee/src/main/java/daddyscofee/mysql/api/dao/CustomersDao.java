package daddyscofee.mysql.api.dao;

import org.springframework.data.repository.CrudRepository;

import daddyscofee.mysql.api.model.Customer;

public interface CustomersDao extends CrudRepository<Customer,Integer> {
	
}
