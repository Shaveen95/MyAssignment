package daddyscofee.mysql.api.dao;

import org.springframework.data.repository.CrudRepository;

import daddyscofee.mysql.api.model.Orders;

public interface OrderItemsDao extends CrudRepository<Orders,String> {

}
