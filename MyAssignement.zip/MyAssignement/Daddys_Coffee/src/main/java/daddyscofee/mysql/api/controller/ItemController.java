package daddyscofee.mysql.api.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import daddyscofee.mysql.api.bservices.ItemServices;
import daddyscofee.mysql.api.model.Items;

@RestController
public class ItemController {
	
	@Autowired
	private ItemServices itemServices;
	
	@RequestMapping(method = RequestMethod.POST, value = "/addItem")
	public void addItem(@RequestBody Items items) {
		itemServices.addItem(items);
	}
	
	
	@RequestMapping("/showItems")
	public List<Items> getAllItems(){
		return itemServices.getAllItems() ;
	}
	
	@RequestMapping("/showItem/{id}")
	public Optional<Items> getItem(@PathVariable String id) {
		return itemServices.getItem(id);
		
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/updateItem/{id}")
	public void updateItem(@RequestBody Items item, @PathVariable String id) {
		itemServices.updateItem(id,item);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteItem/{id}")
	public void deleteItem(@PathVariable String id) {
		itemServices.deleteItems(id);
		
	}

}
