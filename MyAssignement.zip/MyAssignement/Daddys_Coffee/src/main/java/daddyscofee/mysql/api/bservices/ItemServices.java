package daddyscofee.mysql.api.bservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import daddyscofee.mysql.api.dao.ItemsDao;
import daddyscofee.mysql.api.model.Items;

@Service
public class ItemServices {
	
	@Autowired
	private ItemsDao dao;

	public void addItem(Items items) {
		dao.save(items);
		
	}

	public List<Items> getAllItems() {
		List<Items> items = new ArrayList<>();
		dao.findAll()
		.forEach(items::add);
		return items;
	}

	public Optional<Items> getItem(String id) {
		return dao.findById(id);
	}

	public void updateItem(String id, Items item) {
		dao.save(item);
		
	}

	public void deleteItems(String id) {
		dao.deleteById(id);
		
	}

	

}
